import React from 'react'
import Button from "@mui/material/Button";

import SearchResult from "./SearchResult";
import DropDown from "./DropDown";
import {Grid} from "@mui/material";

export default function SearchResults(){
    return (
        <div className="SearchResults CenteredElement">
            <Grid container spacing={3} padding={1} style={{marginBottom: "2vw"}}>
                <Grid item xs={10}/>
                <Grid item xs={2}>
                    <DropDown
                    initialValue={""}
                    label="Sort By"
                    values={["Date", "Agent", "Tag"]}
                    />
                </Grid>
            </Grid>
            <SearchResult
                tags={["Model S", "Troubleshooting"]}
            />
        </div>
    )
}